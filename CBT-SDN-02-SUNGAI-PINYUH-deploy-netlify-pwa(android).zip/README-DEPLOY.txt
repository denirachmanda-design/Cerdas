CBT SDN 02 SUNGAI PINYUH - CARA DEPLOY
=======================================

NETLIFY (https://app.netlify.com/):
1. Buka app.netlify.com > Add new site > Deploy manually
2. Drag & drop file ZIP ini (atau folder hasil ekstrak) ke area deploy
3. Tunggu sampai muncul link, contoh: https://cbt-sdn02-sungai-pinyuh.netlify.app
4. Buka link itu di HP guru/siswa, lalu Install / Add to Home Screen

PWABUILDER (https://www.pwabuilder.com/):
1. Deploy dulu ke Netlify sampai dapat URL publik (https)
2. Buka pwabuilder.com > masukkan URL Netlify tadi > Start
3. Perbaiki jika ada yang merah (biasanya sudah hijau semua)
4. Download paket Android / Windows / iOS bila perlu

ISI PAKET:
- index.html (aplikasi CBT SDN 02, tanpa migrasi/log lama SDN 07)
- manifest.webmanifest (nama CBT SDN 02 SUNGAI PINYUH)
- sw.js (offline cache v1)
- icon-192.png / icon-512.png (logo sekolah)
- netlify.toml + _redirects (config Netlify)

CATATAN: Versi ini mulai dari nol untuk SDN 02. Log/ujian lama SDN 07
sengaja tidak ikut terbawa (fungsi migrasi sudah dihapus).
